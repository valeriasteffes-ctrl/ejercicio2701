peso = float(input("Ingrese su peso en kg"))
altura = float(input("Ingrese su altura en m"))
inc = peso / (altura**2)
print ("su INC es:(inc)")
if inc < 20:
    print("Bajo en peso")
elif inc < 25:
    print("En peso")
elif inc < 35:
    print("Sobrepeso")
else :
    print("obesidad")
 